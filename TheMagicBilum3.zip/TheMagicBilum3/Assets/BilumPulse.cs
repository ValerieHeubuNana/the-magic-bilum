using UnityEngine;

public class BilumPulse : MonoBehaviour
{
    public float pulseAmount = 0.04f;
    public float pulseSpeed = 2f;

    private Vector3 originalScale;

    void Start()
    {
        originalScale = transform.localScale;
    }

    void Update()
    {
        float scale = 1f + Mathf.Sin(Time.time * pulseSpeed) * pulseAmount;
        transform.localScale = originalScale * scale;
    }
}
