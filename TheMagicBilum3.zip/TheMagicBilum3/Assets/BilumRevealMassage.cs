

using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public class BilumRevealMessage : MonoBehaviour, IPointerClickHandler
{
    public TMP_Text messageText;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (messageText != null)
        {
            messageText.text =
                "Every bilum carries meaning. Its colours, patterns and stories connect us to our family, culture and generations before us.";
        }
    }
}
