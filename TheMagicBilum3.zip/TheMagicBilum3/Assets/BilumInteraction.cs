
using UnityEngine;
using UnityEngine.EventSystems;

public class BilumInteraction : MonoBehaviour, IPointerClickHandler
{
    private Vector3 originalScale;
    private bool enlarged = false;

    void Start()
    {
        originalScale = transform.localScale;
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        enlarged = !enlarged;

        if (enlarged)
        {
            transform.localScale = originalScale * 1.2f;
        }
        else
        {
            transform.localScale = originalScale;
        }
    }
}
