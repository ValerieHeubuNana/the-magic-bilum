
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public class PassingStoryInteraction : MonoBehaviour, IPointerClickHandler
{
    public TMP_Text storyText;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (storyText != null)
        {
            storyText.text = "Girl: Our stories can live on when we share them with our children and future generations.";
        }
    }
}
