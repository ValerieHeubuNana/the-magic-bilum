
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public class GrandmaStoryInteraction : MonoBehaviour, IPointerClickHandler
{
    public TMP_Text storyText;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (storyText != null)
        {
            storyText.text = "Grandmother: When I was young, my family taught me these stories. By sharing them with you, I keep our memories and traditions alive.";
        }
    }
}
